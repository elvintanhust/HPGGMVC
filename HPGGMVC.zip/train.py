import torch
from network import Network
from metric import valid
from torch.utils.data import Dataset
import numpy as np
import argparse
import random
from loss import Loss
import dataloader as loader
import os
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from scipy.optimize import linear_sum_assignment
import concurrent.futures
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.functional import normalize


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def contrastive_train(epoch):
    tot_loss = 0.
    mes = torch.nn.MSELoss()

    for batch_idx, (xs, _, _) in enumerate(data_loader):
        for v in range(view):
            xs[v] = xs[v].to(device)
        optimizer.zero_grad()

        hs_ips, qs_ips ,z_sts, ips, hs, qs, xrs, zs = model(xs)# hs:high level feature, qs:pseudo lable, xrs:decoder x, zs:encoder x, ips:induced points

        loss_list = []
        for v in range(view):
            for w in range(v+1, view):
                # We will release the core code upon acceptance of the paper.
                pass

        loss = sum(loss_list)
        loss.backward()
        optimizer.step()
        tot_loss += loss.item()

def fine_tuning_l(epoch,class_num,lmd,beta,temperature_f):
    tot_loss = 0.
    mes = torch.nn.MSELoss()

    for batch_idx, (xs, _, _) in enumerate(data_loader):
        for v in range(view):
            xs[v] = xs[v].to(device)
        optimizer.zero_grad()

        hs_ips, qs_ips ,z_sts, ips, hs, qs, xrs, zs = model(xs)# hs:high level feature, qs:pseudo lable, xrs:decoder x, zs:encoder x, ips:induced points
        loss_list = []
        for v in range(view):
            for w in range(v+1, view):
                # We will release the core code upon acceptance of the paper.
                pass

        loss = sum(loss_list)
        loss.backward()
        optimizer.step()
        tot_loss += loss.item()

def pretrain(epoch):
    tot_loss = 0.
    criterion = torch.nn.MSELoss()
    for batch_idx, (xs, _, _) in enumerate(data_loader):
        for v in range(view):
            xs[v] = xs[v].to(device)
        optimizer.zero_grad()
        _, _, _, _, _, _, xrs, _ = model(xs)
        loss_list = []
        for v in range(view):
            loss_list.append(criterion(xs[v], xrs[v]))
        loss = sum(loss_list)
        loss.backward()
        optimizer.step()
        tot_loss += loss.item()

    # if epoch % 25 == 0:
    # print('Epoch {}'.format(epoch), 'Loss:{:.6f}'.format(tot_loss / len(data_loader)))

Dataname = 'Caltech7'

parser = argparse.ArgumentParser(description='train')
parser.add_argument('--dataset', default=Dataname)
parser.add_argument('--batch_size', type=int, default=256)
parser.add_argument("--temperature_f", type=float, default=0.5)
parser.add_argument("--temperature_l", type=float, default=1.0)
parser.add_argument("--threshold", type=float, default=0.8)
parser.add_argument("--num_point", type=int, default=2)
parser.add_argument("--learning_rate", type=float, default=0.0005)
parser.add_argument("--weight_decay", type=float, default=0.)
parser.add_argument("--workers", type=int, default=8)
parser.add_argument("--seed", type=int, default=10)
parser.add_argument("--mse_epochs", type=int, default=300)
parser.add_argument("--con_epochs", type=int, default=50)
parser.add_argument("--tune_epochs", type=int, default=100)
parser.add_argument("--feature_dim", type=int, default=256)
parser.add_argument("--high_feature_dim", type=int, default=512)
parser.add_argument('--num_heads', type=int, default=8)
parser.add_argument('--hidden_dim', type=int, default=128)
parser.add_argument('--ffn_size', type=int, default=32)
parser.add_argument('--attn_bias_dim', type=int, default=6)
parser.add_argument('--attention_dropout_rate', type=float, default=0.5)
parser.add_argument("--lmd", type=float, default=0.1)
parser.add_argument("--beta", type=float, default=0.1)
parser.add_argument("--gamma", type=float, default=0.1)

args = parser.parse_args()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# device = torch.device("cpu")


dataset, dims, view, data_size, class_num = loader.load_data(args.dataset)

data_loader = torch.utils.data.DataLoader(
    dataset,
    batch_size=args.batch_size,
    shuffle=True,
    drop_last=True,
)

setup_seed(args.seed)

#model init
model = Network(view, dims, args.feature_dim, args.high_feature_dim, class_num, device)

model = model.to(device)

optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)

# training stage
epoch = 1
while epoch <= args.mse_epochs:
    pretrain(epoch)
    epoch += 1
while epoch <= args.mse_epochs + args.con_epochs:
    fine_tuning_l(epoch,class_num,args.lmd,args.beta,args.temperature_f)
    epoch += 1
while epoch <= args.mse_epochs + args.con_epochs + args.tune_epochs:
    contrastive_train(epoch)
    if epoch == args.mse_epochs + args.con_epochs + args.tune_epochs:
        acc, nmi, pur, ari = valid(model,args.batch_size, device, dataset, view, data_size, class_num, eval_h=False)
        print('seed = {:.4f} lmd = {:.4f} beta = {:.4f} lmd_1 = {:.4f} beta_1 = {:.4f} temp_f={:.4f} ACC = {:.4f} NMI = {:.4f} PUR={:.4f}'.format(args.seed, args.lmd, args.beta, args.lmd_1, args.beta_1, args.temperature_f, acc, nmi, pur))
    epoch += 1



