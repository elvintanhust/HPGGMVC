import torch.nn as nn
from torch.nn.functional import normalize
import torch
import torch.nn.functional as F
import math
from sklearn.cluster import KMeans

class Encoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
            nn.Linear(2000, feature_dim),
        )

    def forward(self, x):
        return self.encoder(x)


class Decoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Decoder, self).__init__()
        self.decoder = nn.Sequential(
            nn.Linear(feature_dim, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, input_dim)
        )

    def forward(self, x):
        return self.decoder(x)

class Network(nn.Module):
    def __init__(self, view, input_size, feature_dim, high_feature_dim, class_num, device):
        super(Network, self).__init__()
        self.encoders = []
        self.decoders = []
        for v in range(view):
            self.encoders.append(Encoder(input_size[v], feature_dim).to(device))
            self.decoders.append(Decoder(input_size[v], feature_dim).to(device))
        self.encoders = nn.ModuleList(self.encoders)
        self.decoders = nn.ModuleList(self.decoders)

        self.feature_contrastive_module = nn.Sequential(
            nn.Linear(feature_dim, high_feature_dim),
            # Varying the number of layers of W can obtain the representations with different shapes.
        )
        self.label_contrastive_module = nn.Sequential(
            nn.Linear(feature_dim, class_num),
            nn.Softmax(dim=1)
        )

        self.view = view
        self.class_num =class_num
        #
        self.similarity = nn.CosineSimilarity(dim=2)
        self.criterion = nn.CrossEntropyLoss(reduction="sum")

    def forward(self, xs):
        hs = []
        qs = []
        xrs = []
        zs = []
        ips = []
        z_sts = []
        qs_ips = []
        hs_ips = []
        for v in range(self.view):
            # print(v)
            x = xs[v]
            z = self.encoders[v](x) # encoder x
            h = normalize(self.feature_contrastive_module(z),p=2, dim=1) #high level feature
            q = self.label_contrastive_module(z) #pseudo label
            xr = self.decoders[v](z) # decoder x
            hs.append(h)
            zs.append(z)
            qs.append(q)
            xrs.append(xr)
        return hs_ips, qs_ips, z_sts, ips, hs, qs, xrs, zs

    def forward_cluster(self, xs):
        qs = []
        preds = []
        cat = torch.tensor([]).cuda()
        for v in range(self.view):
            x = xs[v]
            z = self.encoders[v](x)

            cat = torch.cat((cat,z), 1)
            q = self.label_contrastive_module(z)
            pred = torch.argmax(q, dim=1)
            qs.append(q)
            preds.append(pred)

        cat_pre = []
        return qs, preds, cat_pre

    def target_distribution(self, q):
        weight = (q ** 2.0) / torch.sum(q, 0)
        return (weight.t() / torch.sum(weight, 1)).t()
    #
    def mask_correlated_samples(self, N):
        mask = torch.ones((N, N))
        mask = mask.fill_diagonal_(0)
        for i in range(N // 2):
            mask[i, N // 2 + i] = 0
            mask[N // 2 + i, i] = 0
        mask = mask.bool()

        return mask




